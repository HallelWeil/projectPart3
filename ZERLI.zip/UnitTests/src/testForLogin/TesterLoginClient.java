package testForLogin;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import client.ClientController;
import client.IStubForUserController;
import client.MsgController;
import database.DBController;
import msg.Msg;
import msg.MsgType;
import server.ServerMsgController;
import user.User;
import user.UserType;
import usersManagment.LoginConrtroller;
import usersManagment.UserBoundary;
import usersManagment.UserController;

public class TesterLoginClient {

	Msg message;
	stubUserController userCon;
	MsgController msgCon;
	User user;
	UserBoundary userBoun;

	public class stubUserController implements IStubForUserController {

		@Override
		public MsgController login(String username, String password) {
			// TODO Auto-generated method stub
			return msgCon;
		}

		@Override
		public void logout() {
			// TODO Auto-generated method stub

		}
	}

	@Before
	public void setUp() throws Exception {
		message = new Msg();
		msgCon = new MsgController();
		user = new User();
		userCon = new stubUserController();
		userBoun = new UserBoundary(userCon);
	
	}

//tests for client side using Stub///
	@Test
	public void testLoginInCorrectDeatilsForBranchMananger() {
		message.type = MsgType.APPROVE_LOGIN;
		message.data = user;
		msgCon.mgsParser(message);
		boolean expectedRes = true;
		boolean actualRes = userBoun.requestLogin("HallelWeil", "7891011");
		assertEquals(expectedRes, actualRes);
		assertEquals(UserBoundary.CurrentUser, user);

	}

	@Test
	public void testLoginInNotCorrectDeatilsForBranchManagerEmptyPassword() {
		message.type = MsgType.ERROR;
		message.data = "Error";
		msgCon.mgsParser(message);
		boolean actualRes = userBoun.requestLogin("HallelWeil",null);
		String expectedRes = "Error";
		assertFalse(actualRes);
		assertEquals(expectedRes, userBoun.errorMsg);

	}
	


	@Test
	public void testLoginMsgForLoginIsNotCorrect() {
		message.type = MsgType.NONE;
		message.data = user;
		msgCon.mgsParser(message);
		boolean expectedRes = false;
		boolean actualRes = userBoun.requestLogin("HallelWeil", "7891011");
		assertEquals(actualRes, expectedRes);
	}

}
