package testForLogin;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;

import database.DBController;
import msg.Msg;
import msg.MsgType;
import user.User;
import usersManagment.LoginConrtroller;

public class TesterLoginServer {

	DBController DBcon;
	LoginConrtroller loginCon;
	Msg message;
	User user;

	@Before
	public void setUp() throws Exception {
		DBcon = DBController.getInstance();
		DBcon.connectToDB("zelisystem", "root", "tpp@5798");
		loginCon = new LoginConrtroller();
		message = new Msg();
		user = new User();
		DBcon.disconnectUser("HallelWeil");
	}

//test for login on server side//
	@Test
	public void cheackLoginCorrectUserDetails() {

		Msg res = loginCon.login("HallelWeil", "7891011");
		assertEquals(res.type, MsgType.APPROVE_LOGIN);
		user = (User) res.data;
		assertEquals(user.getUsername(), "HallelWeil");
	}

	@Test
	public void checkLoginUserAlreadyConnected() {

		Msg res = loginCon.login("HallelWeil", "7891011");
		assertEquals(res.type, MsgType.APPROVE_LOGIN);
		user = (User) res.data;
		assertEquals(user.getUsername(), "HallelWeil");
		res = loginCon.login("HallelWeil", "7891011");
		assertEquals(res.type, MsgType.ERROR);
		String errorStr = (String) res.data;
		assertEquals(errorStr, "The user already connected");

	}

	@Test
	public void checkLoginUserDetailsAreNull() {

		Msg res = loginCon.login(null, null);
		String errorStr = (String) res.data;
		assertEquals(errorStr, "Wrong username and password");

	}

	@Test
	public void checkLoginUserDetailsAreNotVaild() {

		Msg res = loginCon.login("HallelWeil", "789111");
		assertEquals(res.type, MsgType.ERROR);
		String errorStr = (String) res.data;
		assertEquals(errorStr, "Wrong username and password");

	}

}
