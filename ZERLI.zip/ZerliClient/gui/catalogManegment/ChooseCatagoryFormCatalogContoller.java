package catalogManegment;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.layout.Pane;
import main.IGuiController;
import userGuiManagment.MainWindowGuiManager;
import userGuiManagment.MarketingGuiManager;

public class ChooseCatagoryFormCatalogContoller implements IGuiController {
	private MarketingGuiManager marketingEmployeeGuiManager = MarketingGuiManager.getInstance();
	private MainWindowGuiManager mainWindowManager = MainWindowGuiManager.getInstance();
    @FXML
    private Label errorLabel;
	@FXML
	private ComboBox<String> chooseCatagoryComboBox;

	@FXML
	private Button showCatagoryBtn;

	@FXML
	private Pane updateCatalogPane;

    @FXML
    private Button backBtn;
	@Override
	public Pane getBasePane() {
		// TODO Auto-generated method stub
		return updateCatalogPane;
	}

	@Override
	public void resetController() {
		errorLabel.setText("");

	}

	@Override
	public void openWindow() {
		mainWindowManager.mainWindowController.showNewWindow(updateCatalogPane);
		mainWindowManager.mainWindowController.changeWindowName("Update the Catalog");

	}
	private void setError(String errorString) {
		errorLabel.setText(errorString);

	}
    @FXML
    void goBack(ActionEvent event) {
    	mainWindowManager.userHomeWindowController.openWindow();
    }

    @FXML
    void setComboBoxValues(ActionEvent event) {
    	chooseCatagoryComboBox.getItems().addAll("Birthday Flowers","Wedding Flowers","Anniversary Flowwers","Congratulation Flowwers","New Baby Flowers","Single Items");
    }


    @FXML
    void showCatagory(ActionEvent event) {
    	if(chooseCatagoryComboBox.getItems().isEmpty())
    	{
    		setError("Please choose a catagory to update!");
    	}
    	

    }
	

}
