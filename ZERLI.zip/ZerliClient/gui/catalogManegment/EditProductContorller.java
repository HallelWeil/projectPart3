package catalogManegment;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.Pane;

public class EditProductContorller {
	

    @FXML
    private Button backBtn;

    @FXML
    private ComboBox<String> catagoryComboBox;

    @FXML
    private TextField colorTxt;

    @FXML
    private TextField descriptionTxt;

    @FXML
    private Pane editProductPane;

    @FXML
    private Label erorrLabel;

    @FXML
    private TextField idTxt;

    @FXML
    private TextField nameOfProductTxt;

    @FXML
    private TextField priceTxt;

    @FXML
    private Button saveBnt;

    @FXML
    void goBack(ActionEvent event) {

    }

    @FXML
    void saveChangesOfProduct(ActionEvent event) {

    }

    @FXML
    void setColorOfProduct(ActionEvent event) {

    }

    @FXML
    void setDescriptionOfProduct(ActionEvent event) {

    }

}
