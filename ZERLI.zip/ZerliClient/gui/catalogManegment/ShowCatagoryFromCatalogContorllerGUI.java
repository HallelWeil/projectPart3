package catalogManegment;

import catalog.Product;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;
import main.IGuiController;
import userGuiManagment.MainWindowGuiManager;
import userGuiManagment.MarketingGuiManager;
import usersManagment.CustomerServiceEmployeeBoundary;
import usersManagment.MarketingEmployeeBoundary;

public class ShowCatagoryFromCatalogContorllerGUI implements IGuiController {
	private MarketingGuiManager marketingEmployeeGuiManager = MarketingGuiManager.getInstance();
	private MainWindowGuiManager mainWindowManager = MainWindowGuiManager.getInstance();
	private MarketingEmployeeBoundary marketingEmployeeBoundary = marketingEmployeeGuiManager.getMarketingEmployeeBoundary();
	@FXML
	private Button backBnt;

	@FXML
	private Label CatagoryNameLabel;

	@FXML
	private Button editProductBnt;

	@FXML
	private TableColumn<Product, Integer> productIdCol;

	@FXML
	private TableColumn<Product, Integer> productNameCol;

	@FXML
	private TableView<Product> productsTable;

	@FXML
	private AnchorPane showCatagoryPane;
	ObservableList<Product> productObs = FXCollections.observableArrayList();
	Product selectedProduct;

	public void initializeSurveysTable() {
		productObs.clear();
		productsTable.getItems().clear();
		productIdCol.setCellValueFactory(new PropertyValueFactory<>("Product ID"));
		 productNameCol.setCellValueFactory(new PropertyValueFactory<>("ProductName"));
	}

	@Override
	public void openWindow() {
		initializeSurveysTable();
		try {
			productObs.setAll(marketingEmployeeBoundary.chooseCategory());
		} catch (Exception e) {
			//
		}
		 productsTable.setItems(productObs);
		mainWindowManager.mainWindowController.changeWindowName("Choose a catagory");
		mainWindowManager.mainWindowController.showNewWindow(showCatagoryPane);
	}

	@FXML
	void showProductToEdit(ActionEvent event) {

	}

	@FXML
	void goBack(ActionEvent event) {

	}

	@Override
	public Pane getBasePane() {
		// TODO Auto-generated method stub
		return showCatagoryPane;
	}

	@Override
	public void resetController() {
		// TODO Auto-generated method stub

	}

}
