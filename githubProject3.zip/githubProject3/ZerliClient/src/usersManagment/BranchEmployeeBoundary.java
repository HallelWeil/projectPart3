package usersManagment;

import java.util.ArrayList;
import client.ClientController;
import client.MsgController;
import msg.MsgType;
import surveyController.Exception;
import msg.Msg;



public class BranchEmployeeBoundary extends UserBoundary 
{
	private ClientController client;
	private MsgController msgController;
	
	 public void requestEnterSurveyAnswers(int [] answers) throws Exception
	 {
		 msgController = client.sendMsg(msgController.createADD_SURVEY_ANSWERSMsg(answers));
		if(msgController.getType() != MsgType.ADD_SURVEY_ANSWERS)
			 throw new Exception("cannot request enter survey answers");
		
	 }
}
