package common;

public enum Status {
	Active, Completed, WaitingForAprroval, Canceled
}
