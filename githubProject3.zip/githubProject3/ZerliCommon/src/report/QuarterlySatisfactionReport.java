package report;

public class QuarterlySatisfactionReport extends Report{

	public QuarterlySatisfactionReport(int month, int year) {
		super(month, year, ReportType.QUARTERLY_SATISFACTION_REPORT, "ALL");
	}

}