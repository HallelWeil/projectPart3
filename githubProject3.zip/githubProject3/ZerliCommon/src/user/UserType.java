package user;

public enum UserType {

	NonAuthorizedCustomer, AuthorizedCustomer, BranchManager, BranchEmployee, CustomerServiceEmloyee, MarketingEmployee,
	Courier, CEO
}