package customer;

import javafx.scene.layout.Pane;
import main.IGuiController;

public class CartGuiController implements IGuiController {

	@Override
	public Pane getBasePane() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void resetController() {
		// TODO Auto-generated method stub

	}

	@Override
	public void openWindow() {
		// TODO Auto-generated method stub

	}

}
