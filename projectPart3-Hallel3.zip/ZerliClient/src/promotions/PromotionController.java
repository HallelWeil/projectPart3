package promotions;

public class PromotionController {

	
	/**
	 * create new promotion and send it to the server
	 * @param productID
	 * @param discount
	 * @param promotionText
	 */
	public void activatePromotion(int productID, double discount, String promotionText) {
		
	}
}
