package usersManagment;

import promotions.PromotionController;

public class MarketingEmployeeBoundary {

	private PromotionController promotionController;
	
	public void updateCatalog() {
		
	}
	public void requestActivatingPromotion(int productID, double discount, String promotionText) {
		
	}
}
