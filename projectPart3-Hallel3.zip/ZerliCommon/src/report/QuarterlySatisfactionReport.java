package report;

public class QuarterlySatisfactionReport extends Report{

	public QuarterlySatisfactionReport(int month, int year) {
		super(month, year, ReportType.QUARTERLY_SATISFACTION_REPORT, "ALL");
	}

	public String getStartMonth() {
		// TODO Auto-generated method stub
		return null;
	}

	public String getStartYear() {
		// TODO Auto-generated method stub
		return null;
	}

	public String getEndMonth() {
		// TODO Auto-generated method stub
		return null;
	}

	public String getEndYear() {
		// TODO Auto-generated method stub
		return null;
	}

	public int[] getComplaintsPerMonth() {
		// TODO Auto-generated method stub
		return null;
	}

}
