package user;

public enum UserStatus {
	Active, Frozen, NotActive
}
