package usersManagment;

import user.*;

public class UserManagmentController {

	/**
	 * update user type + status, can be null if only wanted to update one of the
	 * fields return boolean if the request succeed
	 * 
	 * @param userName
	 * @param type
	 * @param status
	 * @return
	 */
	public boolean updateUserData(String userName, UserType type, UserStatus status) {

		return true;
	}
	public void createNewCostumer() {
		
	}
}
