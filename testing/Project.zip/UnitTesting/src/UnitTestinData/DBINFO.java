package UnitTestinData;

/**
 * save the database info for all the tests
 *
 */
public class DBINFO {
	public static String DBname = "zelisystemtest";
	public static String DBUser = "root";
	public static String DBPassword = "Aa123456";
}
