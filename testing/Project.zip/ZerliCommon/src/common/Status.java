package common;

/**
 * a general status, can be used for every purpose
 * 
 * @author halel
 *
 */
public enum Status {
	Active, Completed, WaitingForAprroval, Canceled
}
